/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankapp;

/**
 *
 * @author koket
 */
public class EmailNotifier implements Notifier{
    @Override 
    public void notify(String message){
        System.out.println("Sending via email: Deposited successfully" + message);
    }
    
}
