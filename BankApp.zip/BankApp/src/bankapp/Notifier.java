/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bankapp;

/**
 *
 * @author koket
 */
public interface Notifier {
    void notify (String message);
    
}
