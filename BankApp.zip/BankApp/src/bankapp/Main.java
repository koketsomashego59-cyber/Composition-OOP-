/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bankapp;

/**
 *
 * @author koket
 */
public class Main {
    public static void main (String [] args){
        Notifier smsNotifier = new SMSNotifier();
        Notifier emailNotifier = new EmailNotifier();
        
        BankApp account1 = new BankApp("01", 200, smsNotifier);
        account1.deposit(250);
        
        BankApp account2 = new BankApp("02", 500, emailNotifier);
        account2.deposit(500);
        
    }
    
}
