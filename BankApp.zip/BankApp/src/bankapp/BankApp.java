/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankapp;

/**
 *
 * @author koket
 */
public class BankApp {

        private final String accountNumber;
        private double balance;
        private final Notifier notifier; // This is Composition
    
        public BankApp(String accountNumber, double balance, Notifier notifier){
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.notifier = notifier;
        }
        
        public void deposit(double amount){
            balance += amount;
            notifier.notify("Deposit of R: " + amount + " Successful. Balance: R" + balance);
        }   
}
